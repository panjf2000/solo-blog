title: ACM刷题之-POJ-2192(Zipper)
date: '2018-04-04 22:47:11'
updated: '2019-07-21 21:01:44'
tags: [ACM, 算法, 数据结构]
permalink: /POJ-2192
---
# Description
>Given three strings, you are to determine whether the third string can be formed by combining the characters in the first two strings. The first two strings can be mixed arbitrarily, but each must stay in its original order. 
For example, consider forming "tcraete" from "cat" and "tree": 
String A: cat 
String B: tree 
String C: tcraete 
As you can see, we can form the third string by alternating characters from the two strings. As a second example, consider forming "catrtee" from "cat" and "tree": 
String A: cat 
String B: tree 
String C: catrtee 
Finally, notice that it is impossible to form "cttaree" from "cat" and "tree". 

# Input

The first line of input contains a single positive integer from 1 through 1000. It represents the number of data sets to follow. The processing for each data set is identical. The data sets appear on the following lines, one data set per line. 

For each data set, the line of input consists of three strings, separated by a single space. All strings are composed of upper and lower case letters only. The length of the third string is always the sum of the lengths of the first two strings. The first two strings will have lengths between 1 and 200 characters, inclusive. 

# Output

For each data set, print: 

Data set n: yes 

if the third string can be formed from the first two, or 

Data set n: no 

if it cannot. Of course n should be replaced by the data set number. See the sample output below for an example. 

Sample Input
```
3 cat tree tcraete cat tree catrtee cat tree cttaree
```

# Sample Output
```
Data set 1: yes Data set 2: yes Data set 3: no
```

# 我的答案
```c++
#include<iostream>
using namespace std;
 
char A[201];
char B[201];
char C[401];
 
int N; /* 测试次数 */
 
int DFS(int x, int y)
{
    if(x == -1 && y == -1)
        return 1;
    if(x >= 0 && A[x] == C[x+y+1])
    {
        if(DFS(x-1,y))
            return 1;
    }
    if(y >= 0 && B[y] == C[x+y+1])
    {
        if(DFS(x,y-1))
            return 1;
    }
    return 0;
}
 
int main()
{
    scanf("%d", &N);
    for(int k = 1; k <= N; ++k)   /* N个测试用例 */
    {
        scanf("%s %s %s", A, B, C);
        printf("Data set %d: %s\n", k, DFS(strlen(A)-1,strlen(B)-1) ? "yes" : "no");
    }
    return 0;
}
```