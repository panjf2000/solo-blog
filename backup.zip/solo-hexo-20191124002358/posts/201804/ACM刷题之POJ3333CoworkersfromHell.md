title: ACM刷题之-POJ-3333(Co-workers from Hell)
date: '2018-04-01 10:55:44'
updated: '2019-07-21 21:04:15'
tags: [ACM, 算法, 数据结构]
permalink: /co-workers-from-hell
---
# Description

>A watchman has to check a number of chambers in the factory each night according to a schedule which specifies the order in which the chambers must be visited and the time it takes to check each chamber. The watchman starts his job each night starting from the first chamber and leaves the factory and goes home when he checks the final chamber. He normally checks all other chambers, but in our story he may not actually do so. Having access to this schedule, a co-worker wants to have some fun one night by teasing him and making him go home very late. To do this, he can make some tricks in a number of chambers before the watchman arrives and starts his job. Each trick in one chamber will deceive the watchman as if something may be happening in one other chamber. This makes the watchman stay a different amount of time in that chamber and continue his check in another chamber which may be different from the chamber he normally checks afterwards. When he goes to a new chamber, he continues his normal check up to the end (and thus may not check some chambers at all). For example, if there are five chambers which are checked in order in the normal situations and the only trick made is in chamber 2 which makes the watchman go and check the chamber 4, the watchman takes this path along chambers: 1 - 2 - 4 - 5, and then goes home. We assume that a trick in one chamber is only effective the first time the watchman visits that chamber, and is ineffective in future visits to that chamber. With all this information, we want to write a program and help the co-worker to plan his tricks in a way to maximize the time that the watchman stays in the factory.

# Input

>The first number in the input line, T is the number of test cases. The first line of each test case contains a single integer n (0 ≤ n ≤ 100) which is the number of chambers. Following the first line, there are nlines describing the chambers in order. Each line contains three integers d td tc where d is the time the watchman stays in that chamber in a normal checking, td is the time he stays there if we had made a trick in that chamber, and tc is the next chamber he must go to if the trick is made. The starting chamber is always 1, and the final chamber is always n.

# Output

>The output contains T lines, each corresponding to an input test case in that order. The output line contains a single integer indicating the maximum time possible in which the watchman exits the last chamber in normal way.

# Sample Input
```
1 5 1 2 2 1 2 4 1 1 4 1 2 5 1 2 4
```

# Sample Output
```
10
```

# 我的答案
```c++
#include <iostream>
#include <vector>
#include <string>
#include <cstring>
#include <set>

using namespace std;

struct Tag {
    int normal, trick, next;

    Tag() {}
    Tag(int n, int t, int ne) : normal(n), trick(t), next(ne) {}
};

int ans = 0;
void dfs(const vector<Tag> &chambers, int pos, vector<int> &used, int acc) {
    if(pos == (int)chambers.size()) {
        ans = max(ans, acc);
        return;
    }

    if(!used[pos]) {
        used[pos] = 1;
        dfs(chambers, chambers[pos].next, used, acc+chambers[pos].trick);
        used[pos] = 0;
        if(chambers[pos].next <= pos) return;
    }
    dfs(chambers, pos+1, used, acc+chambers[pos].normal);
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    int T;
    cin >> T;
    while(T--) {
        int N;
        cin >> N;
        vector<Tag> chambers;
        for(int i = 0; i < N; ++i) {
            int a, b, c;
            cin >> a >> b >> c;
            --c;
            chambers.push_back(Tag(a, b, c));
        }

        vector<int> used(N, 0);
        ans = 0;
        for(int i = 0; i < N; ++i) {
            if(chambers[i].next > i) {
                int cost = 0;
                for(int j = i; j < chambers[i].next; ++j) {
                    cost += chambers[j].normal;
                }
                if(cost >= chambers[i].trick) {
                    used[i] = 1;
                }
            }
        }
        dfs(chambers, 0, used, 0);
        cout << ans << endl;
    }

    return 0;
}
```
