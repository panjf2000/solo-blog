title: ACM刷题之-POJ-1396(Simple Arithmetics)
date: '2018-04-04 22:50:53'
updated: '2019-07-21 21:01:26'
tags: [ACM, 算法, 数据结构]
permalink: /POJ-1396
---
# Description

>One part of the new WAP portal is also a calculator computing expressions with very long numbers. To make the output look better, the result is formated the same way as is it usually used with manual calculations. 

>Your task is to write the core part of this calculator. Given two numbers and the requested operation, you are to compute the result and print it in the form specified below. With addition and subtraction, the numbers are written below each other. Multiplication is a little bit more complex: first of all, we make a partial result for every digit of one of the numbers, and then sum the results together. 

# Input

There is a single positive integer T on the first line of input. It stands for the number of expressions to follow. Each expression consists of a single line containing a positive integer number, an operator (one of +, - and *) and the second positive integer number. Every number has at most 500 digits. There are no spaces on the line. If the operation is subtraction, the second number is always lower than the first one. No number will begin with zero.

# Output

For each expression, print two lines with two given numbers, the second number below the first one, last digits (representing unities) must be aligned in the same column. Put the operator right in front of the first digit of the second number. After the second number, there must be a horizontal line made of dashes (-). 

For each addition or subtraction, put the result right below the horizontal line, with last digit aligned to the last digit of both operands. 

For each multiplication, multiply the first number by each digit of the second number. Put the partial results one below the other, starting with the product of the last digit of the second number. Each partial result should be aligned with the corresponding digit. That means the last digit of the partial product must be in the same column as the digit of the second number. No product may begin with any additional zeros. If a particular digit is zero, the product has exactly one digit -- zero. If the second number has more than one digit, print another horizontal line under the partial results, and then print the sum of them. 

There must be minimal number of spaces on the beginning of lines, with respect to other constraints. The horizontal line is always as long as necessary to reach the left and right end of both numbers (and operators) right below and above it. That means it begins in the same column where the leftmost digit or operator of that two lines (one below and one above) is. It ends in the column where is the rightmost digit of that two numbers. The line can be neither longer nor shorter than specified. 

Print one blank line after each test case, including the last one. 


# Sample Input
```
4 12345+67890 324-111 325*4405 1234*4
```
# Sample Output
```
 12345 +67890 ------  80235  324 -111 ----  213     325   *4405   -----    1625      0  1300 1300 ------- 1431625 1234   *4 ---- 4936
```

# 我的答案
```c++
import java.math.BigInteger;
import java.util.Scanner;
import java.io.*;

import javax.jws.soap.SOAPBinding;
public class Main {
	static private final String INPUT = "data1.in";
	static private final String OUTPUT = "1.out";
	public static void main(String[] args) throws IOException {
		FileInputStream instream = null;
		PrintStream outstream = null;
		/*try {
			instream = new FileInputStream(INPUT);
			outstream = new PrintStream(new FileOutputStream(OUTPUT));
			System.setIn(instream);
			System.setOut(outstream);
		} catch (Exception e) {
			System.err.println("Error Occurred.");
		}*/
		int i, j, t;
		char cc = 0;
		BigInteger a = BigInteger.ZERO;
		BigInteger b = BigInteger.ZERO;
		BigInteger c = BigInteger.ZERO;
		//Scanner cin = new Scanner(System.in);
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
		//BufferedReader read = new BufferedReader(new FileReader(INPUT));
		//String s = cin.next();
		//System.out.println(s);
		t = Integer.valueOf(read.readLine());
		while (t--!=0) {
			StringBuffer s0  =  new  StringBuffer();
			String str = read.readLine();
			String tmp;
			for (i = 0; i <= str.length(); i++) {
				if (str.charAt(i) == '+' || str.charAt(i) == '*'
						|| str.charAt(i) == '-') {
					cc = str.charAt(i);
					break;
				}
			}
			if (cc == '+') {
				String[] strs = str.split("\\+");
				a = new BigInteger(strs[0]);
				b = new BigInteger(strs[1]);
				c = a.add(b);
				Integer min = 0;
				tmp = String.valueOf(c);
				if (min < tmp.length()) {
					min = tmp.length();
				}
				if (min < strs[0].length()) {
					min = strs[0].length();
				}
				if (min < strs[1].length() + 1) {
					min = strs[1].length() + 1;
				}
				for (i = 0; i < min - strs[0].length(); i++) {

					//s0.append(" ");
					s0.append(" ");
				}
				//System.out.println(strs[0]);
				s0.append(strs[0]);
				s0.append("\n");
				for (i = 0; i < min - strs[1].length() - 1; i++) {
					//s0.append(" ");
					s0.append(" ");
				}
				//System.out.println("+" + strs[1]);
				s0.append("+");
				s0.append(strs[1]);
				s0.append("\n");
				for (i = 0; i < min; i++) {
					//s0.append("-");
					s0.append("-");
				}
				//System.out.println();
				s0.append("\n");
				for (i = 0; i < min - tmp.length(); i++) {
					s0.append(" ");
				}
				//System.out.println(tmp);
				s0.append(tmp);
				s0.append("\n");

			} else if (cc == '-') {
				String[] strs = str.split("\\-");
				a = new BigInteger(strs[0]);
				b = new BigInteger(strs[1]);
				c = a.subtract(b);
				Integer min = 0;
				Integer min2=strs[1].length()+1;
				tmp = String.valueOf(c);
				if(min2<tmp.length())
				{
					min2=tmp.length();
				}
				if (min < tmp.length()) {
					min = tmp.length();
				}
				if (min < strs[0].length()) {
					min = strs[0].length();
				}
				if (min < strs[1].length() + 1) {
					min = strs[1].length() + 1;
				}
				for (i = 0; i < min - strs[0].length(); i++) {
					s0.append(" ");
				}
				//System.out.println(strs[0]);
				s0.append(strs[0]);
				s0.append("\n");
				for (i = 0; i < min - strs[1].length() - 1; i++) {
					s0.append(" ");
				}
				//System.out.println("-" + strs[1]);
				s0.append("-");
				s0.append(strs[1]);
				s0.append("\n");
				for(i=0;i<min-min2;i++)
				{
					s0.append(" ");
				}
				for (i = 0; i < min2; i++) {
					s0.append("-");
				}
				//System.out.println();
				s0.append("\n");
				for (i = 0; i < min - tmp.length(); i++) {
					s0.append(" ");
				}
				//System.out.println(tmp);
				s0.append(tmp);
				s0.append("\n");
			} else if (cc == '*') {
				String[] strs = str.split("\\*");
				a = new BigInteger(strs[0]);
				b = new BigInteger(strs[1]);
				c = a.multiply(b);
				Integer min = 0;
				tmp = String.valueOf(c);
				int len = tmp.length();
				if(len<strs[1].length()+1)
				{
					len=strs[1].length()+1;
				}
				min=strs[1].length()+1;
				for (i = 0; i < len - strs[0].length(); i++) {
					s0.append(" ");
				}
				//System.out.println(strs[0]);
				s0.append(strs[0]);
				s0.append("\n");
				for (i = 0; i < len - strs[1].length() - 1; i++) {
					s0.append(" ");
				}
				//System.out.println("*" + strs[1]);
				s0.append("*");
				s0.append(strs[1]);
				s0.append("\n");
				if (strs[1].length() != 1) {


					if (len < min)
						len = min;
					int le2 = strs[1].length();
					BigInteger d = BigInteger.ZERO;
					for (i = 0; i < le2; i++) {
						d = BigInteger.valueOf(Long.valueOf(String
								.valueOf(strs[1].charAt(le2 - 1 - i))));
						d = d.multiply(a);
						String tmp2 = String.valueOf(d);
						if(i==0)
						{
							if(min<tmp2.length())
							{
								min=tmp2.length();
							}
							for (j = 0; j < len - min; j++) {
								s0.append(" ");
							}
							for (j = 0; j < min; j++) {
								s0.append("-");
							}
		//					System.out.println();
							s0.append("\n");
						}
						for (j = 0; j < len - tmp2.length() - i; j++) {
							s0.append(" ");
						}
						//System.out.println(tmp2);
						s0.append(tmp2);
						s0.append("\n");
					}
					for (i = 0; i < len - tmp.length(); i++) {
						s0.append(" ");
					}
					for (i = 0; i < tmp.length(); i++) {
						//System.out.printf("-");
						s0.append("-");
					}
					//System.out.println();
					s0.append("\n");
				}
				else
				{
					int min2=tmp.length();
					if(min2<strs[1].length()+1)
					{
						min2=strs[1].length()+1;
					}
					for (i = 0; i < len - min2; i++) {
						s0.append(" ");
					}
					for (i = 0; i < min2; i++) {
						//System.out.printf("-");
						s0.append("-");
					}
					//System.out.println();
					s0.append("\n");
				}
				for (i = 0; i < len - tmp.length(); i++) {
					s0.append(" ");
				}
				//System.out.println(c);
				s0.append(c);
				s0.append("\n");
			}
			//if(t-1!=0)System.out.println();

			System.out.println(s0);
			//System.out.println("\r");
		}
		//}
	}
}
```