title: ACM刷题之-POJ-3662(Telephone Lines)
date: '2018-04-01 10:57:46'
updated: '2019-07-21 21:02:49'
tags: [ACM, 算法, 数据结构]
permalink: /POJ-3662
---
# Description

>Farmer John wants to set up a telephone line at his farm. Unfortunately, the phone company is uncooperative, so he needs to pay for some of the cables required to connect his farm to the phone system.

>There are N (1 ≤ N ≤ 1,000) forlorn telephone poles conveniently numbered 1..N that are scattered around Farmer John's property; no cables connect any them. A total of P (1 ≤ P ≤ 10,000) pairs of poles can be connected by a cable; the rest are too far apart.

>The i-th cable can connect the two distinct poles Ai and Bi, with length Li (1 ≤ Li ≤ 1,000,000) units if used. The input data set never names any {Ai, Bi} pair more than once. Pole 1 is already connected to the phone system, and pole N is at the farm. Poles 1 and N need to be connected by a path of cables; the rest of the poles might be used or might not be used.

>As it turns out, the phone company is willing to provide Farmer John with K (0 ≤ K < N) lengths of cable for free. Beyond that he will have to pay a price equal to the length of the longest remaining cable he requires (each pair of poles is connected with a separate cable), or 0 if he does not need any additional cables.

>Determine the minimum amount that Farmer John must pay.

# Input

* Line 1: Three space-separated integers: N, P, and K
* Lines 2..P+1: Line i+1 contains the three space-separated integers: Ai, Bi, and Li

# Output

* Line 1: A single integer, the minimum amount Farmer John can pay. If it is impossible to connect the farm to the phone company, print -1.

# Sample Input
```
5 7 1 1 2 5 3 1 4 2 4 8 3 2 3 5 2 9 3 4 7 4 5 6
```

# Sample Output
```
4
```

# 我的答案
```c++
#include<stdio.h>  
#include<string.h>  
#include<algorithm>  
using namespace std;  
struct edge  
{  
    int a,b,l;  
}bian[10100];  
int map[1010][1010];  
int vis[1010];  
int dist[1010];  
int inf=0x7ffffff;  
bool cmp(struct edge a,struct edge b)  
{  
    return a.l<b.l;  
}  
void build(int l,int n,int p)  
{  
    int i,j;  
    for(i=0;i<=n;++i)  
    {  
        for(j=0;j<=n;++j)  
        {  
            map[i][j]=inf;  
        }  
    }  
      
    for(i=0;i<p;++i)  
    {  
        int a,b;  
        a=bian[i].a;  
        b=bian[i].b;  
        if(bian[i].l<=l)  
        {  
              
            map[a][b]=map[b][a]=0;  
        }else map[a][b]=map[b][a]=1;  
    }  
}  
int xun(int n)//在剩余的节点中寻找到1最近的    
{    
    int xia=-1,i;    
    for(i=1;i<=n;i++)    
        if(vis[i]==0&&(xia==-1||dist[i]<dist[xia]))    
            xia=i;    
        return xia;    
}    
int djk(int n)    
{    
    int i,j,just;    
    for(i=1;i<=n;i++)//初始化    
        dist[i]=map[1][i];    
    memset(vis,0,sizeof(vis));    
    vis[1]=1;    
    for(i=2;i<=n;i++)    
    {    
        just=xun(n);    
        vis[just]=1;//just最近，将他标为已找到最短路径    
        for(j=1;j<=n;j++)//更新剩余的    
            if(vis[j]==0&&dist[j]>dist[just]+map[just][j])    
                dist[j]=dist[just]+map[just][j];    
    }    
    return dist[n];  
}    
int bin(int n,int p,int k)  
{  
    int head,tail;  
    head=0;  
    tail=p-1;  
    int mid;  
    while(head<=tail)  
    {  
        int mid=(head+tail)>>1;  
        build(bian[mid].l,n,p);  
        if(djk(n)<=k)//求出最小的  
        {  
            tail=mid-1;  
        }  
        else head=mid+1;  
    }  
    return head;  
}  
int main()  
{  
    int i,n,p,k;  
    while(scanf("%d%d%d",&n,&p,&k)!=EOF)  
    {  
        for(i=0;i<p;i++)  
        {  
            scanf("%d%d%d",&bian[i].a,&bian[i].b,&bian[i].l);  
        }  
        sort(bian,bian+p,cmp);  
        build(0,n,p);  
        int duan=djk(n);  
        if(duan==inf)  
        {  
            printf("-1\n");  
        }else  
        {  
            if(duan<=k)  
                printf("0\n");  
            else printf("%d\n",bian[bin(n,p,k)].l);  
        }  
    }  
    return 0;  
}
```