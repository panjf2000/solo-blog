title: Ubuntu下通过PPA仓库安装JDK
date: '2018-04-05 08:07:57'
updated: '2019-07-21 20:48:16'
tags: [Ubuntu, JDK]
permalink: /install-jdk-via-ppa-in-ubuntu
---
>摘要: 在Ubuntu14.04下通过PPA仓库安装JDK，这样就无需自己配置环境变量，完全自动配置好，比较方便，而且还可以保持JDK的版本是最新的．

**在我们继续了解如何安装Java之前，让我们快速地了解JRE、OpenJDK和Oracle JDK之间的不同之处。**

JRE（Java Runtime Environment），它是你运行一个基于Java语言应用程序的所正常需要的环境。如果你不是一个程序员的话，这些足够你的需要。

JDK代表Java开发工具包，如果你想做一些有关Java的开发（阅读程序），这正是你所需要的。

OpenJDK是Java开发工具包的开源实现，Oracle JDK是Java开发工具包的官方Oracle版本。尽管OpenJDK已经足够满足大多数的案例，但是许多程序比如Android Studio建议使用Oracle JDK，以避免UI/性能问题。

检查Java是否已经安装在Ubuntu上
打开终端，输入以下命令：

    java -version

如果有看到类似以下的输出，则表明你的电脑上已经安装好了JDK，否则就是没有安装：

    java version "1.7.0_76"

    Java(TM) SE Runtime Environment (build 1.7.0_76-b13)

    Java HotSpot(TM) 64-Bit Server VM (build 24.76-b04, mixed mode)

在Ubuntu和Linux Mint上安装OpenJDK

    sudo apt-get install default jdk

特殊地，如果你想要安装Java 7或者Java 6等等，你可以使用openjdk-7-jdk/openjdk-6jdk，但是记住在此之前安装openjdk-7-jre/openjdk-6-jre。


在Ubuntu和Linux Mint上安装Oracle JDK

    sudo add-apt-repository ppa:webupd8team/java

    sudo apt-get update

    sudo apt-get install oracle-java8-installer

设置 Java 8 环境变量：

    sudo apt-get install oracle-java8-set-default


切换为 Java 7 ：

    sudo update-java-alternatives -s java-7-oracle

再切换为 Java 8：

    sudo update-java-alternatives -s java-8-oracle

如果你想安装Java 7(i.e Java 1.7)，在上面的命令中用java7代替java8。

卸载Oracle Java
如果你不再想使用Oracle Java(JDK)7,想用OpenJDK了，你只需卸载Oracle JDK Installer，这样OpenJDK就又变成当前使用的java了：

    sudo apt-get remove oracle-java7-installer

