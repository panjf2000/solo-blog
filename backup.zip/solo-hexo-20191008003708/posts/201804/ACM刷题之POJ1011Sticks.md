title: ACM刷题之-POJ-1011(Sticks)
date: '2018-04-04 22:59:52'
updated: '2019-07-21 21:00:39'
tags: [ACM, 算法, 数据结构]
permalink: /POJ-1011
---
# Description

>George took sticks of the same length and cut them randomly until all parts became at most 50 units long. Now he wants to return sticks to the original state, but he forgot how many sticks he had originally and how long they were originally. Please help him and design a program which computes the smallest possible original length of those sticks. All lengths expressed in units are integers greater than zero.

# Input

The input contains blocks of 2 lines. The first line contains the number of sticks parts after cutting, there are at most 64 sticks. The second line contains the lengths of those parts separated by the space. The last line of the file contains zero.

# Output

The output should contains the smallest possible length of original sticks, one per line.

# Sample Input
```
9 5 2 1 5 2 1 5 2 1 4 1 2 3 4 0
```

# Sample Output
```
6 5
```

# 我的答案
```c++
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

 public class Main {

     static boolean[] used;
     static int len;
     static int[] s;
     static int sum;
     static int max;
     static int parts;

     public static void main(String[] args) throws Exception {
         BufferedReader read = new BufferedReader(new InputStreamReader(
                 System.in));
         while ((len = Integer.parseInt(read.readLine())) != 0) {
             s = new int[len];
             StringTokenizer take = new StringTokenizer(read.readLine());
             int index = 0;
             sum = 0;
             used = new boolean[len];
             while (take.hasMoreTokens()) {
                 s[index] = Integer.parseInt(take.nextToken());
                 sum += s[index++];
             }
             Arrays.sort(s);
             max = s[len - 1];
             for (; max <= sum; max++) {
                 if (sum % max == 0) {
                     parts = sum / max;
                     if (search(0, len - 1, 0)) {
                         System.out.println(max);
                         break;
                     }
                 }
             }
         }
     }

     public static boolean search(int res, int next, int cpl) {
         if (res == max) {
             res = 0;
             next = len - 2;
             cpl++;
         }
         if (cpl == parts) {
             return true;
         }
         while (next >= 0) {
             if (used[next] == false) {
                 if (res + s[next] <= max) {
                     used[next] = true;
                     if (search(res + s[next], next - 1, cpl)) {
                         return true;
                     }
                     used[next] = false;
                     if (res == 0) {
                         break;
                     }
                     if (res + s[next] == max) {
                         break;
                     }
                 }
                 int i = next - 1;
                 while (i >= 0 && s[i] == s[next]) {
                     i--;
                 }
                 next = i;
                 int l_s = 0;
                 for (int j = next; j >= 0; j--) {
                     if (!used[j]) {
                         l_s += s[j];
                     }
                 }
                 if (l_s < max - res) {
                     break;
                 }
                 continue;
             }
             next--;
         }
         return false;
     } 
}
```